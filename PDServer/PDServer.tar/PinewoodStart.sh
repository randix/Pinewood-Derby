#!/bin/sh

./PDServer.py &
./timer.py --sim &
